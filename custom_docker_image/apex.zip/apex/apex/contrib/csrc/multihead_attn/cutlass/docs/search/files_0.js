var searchData=
[
  ['batched_5freduction_2eh',['batched_reduction.h',['../batched__reduction_8h.html',1,'']]],
  ['batched_5freduction_5ftraits_2eh',['batched_reduction_traits.h',['../batched__reduction__traits_8h.html',1,'']]]
];
