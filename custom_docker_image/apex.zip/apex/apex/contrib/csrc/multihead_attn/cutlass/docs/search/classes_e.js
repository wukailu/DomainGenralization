var searchData=
[
  ['regulartilepredicatefunctor',['RegularTilePredicateFunctor',['../structcutlass_1_1RegularTilePredicateFunctor.html',1,'cutlass']]],
  ['remove_5fconst',['remove_const',['../structcutlass_1_1platform_1_1remove__const.html',1,'cutlass::platform']]],
  ['remove_5fconst_3c_20const_20t_20_3e',['remove_const&lt; const T &gt;',['../structcutlass_1_1platform_1_1remove__const_3_01const_01T_01_4.html',1,'cutlass::platform']]],
  ['remove_5fcv',['remove_cv',['../structcutlass_1_1platform_1_1remove__cv.html',1,'cutlass::platform']]],
  ['remove_5fvolatile',['remove_volatile',['../structcutlass_1_1platform_1_1remove__volatile.html',1,'cutlass::platform']]],
  ['remove_5fvolatile_3c_20volatile_20t_20_3e',['remove_volatile&lt; volatile T &gt;',['../structcutlass_1_1platform_1_1remove__volatile_3_01volatile_01T_01_4.html',1,'cutlass::platform']]],
  ['reshapethreads',['ReshapeThreads',['../structcutlass_1_1gemm_1_1ReshapeThreads.html',1,'cutlass::gemm']]],
  ['reshapethreads_3c_20tile_5f_2c_20threads_5f_2c_20true_20_3e',['ReshapeThreads&lt; Tile_, Threads_, true &gt;',['../structcutlass_1_1gemm_1_1ReshapeThreads_3_01Tile___00_01Threads___00_01true_01_4.html',1,'cutlass::gemm']]],
  ['reshapetile',['ReshapeTile',['../structcutlass_1_1ReshapeTile.html',1,'cutlass']]],
  ['reshapetile_3c_20tile_5f_2c_20kaccesssize_5f_2c_20true_20_3e',['ReshapeTile&lt; Tile_, kAccessSize_, true &gt;',['../structcutlass_1_1ReshapeTile_3_01Tile___00_01kAccessSize___00_01true_01_4.html',1,'cutlass']]],
  ['rowmajor',['RowMajor',['../structcutlass_1_1MatrixLayout_1_1RowMajor.html',1,'cutlass::MatrixLayout']]],
  ['rowmajorblocklinear',['RowMajorBlockLinear',['../structcutlass_1_1MatrixLayout_1_1RowMajorBlockLinear.html',1,'cutlass::MatrixLayout']]],
  ['rowmajorblockswizzle',['RowMajorBlockSwizzle',['../structcutlass_1_1gemm_1_1RowMajorBlockSwizzle.html',1,'cutlass::gemm']]],
  ['rowmajorinterleaved',['RowMajorInterleaved',['../structcutlass_1_1MatrixLayout_1_1RowMajorInterleaved.html',1,'cutlass::MatrixLayout']]]
];
